﻿using System;
using System.Collections.Generic;
using System.Text;


public enum Seasons
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
} 